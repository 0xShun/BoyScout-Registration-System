#!/usr/bin/env python3
"""
Preview Registration Confirmation Email
Shows what the registration success email will look like
"""

# Sample data
user_data = {
    'first_name': 'Shawn Michael',
    'last_name': 'Sudaria',
    'email': 'shawnmichaelsudaria14@gmail.com',
    'username': 'shawnsudaria',
}

amount = 500.00
years = 1
login_url = 'localhost:8000/accounts/login/'

email_message = f'''
Dear {user_data['first_name']} {user_data['last_name']},

🎉 Congratulations! Your registration has been successfully completed!

Payment Details:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Amount Paid: ₱{amount}
✓ Payment Status: Verified
✓ Account Status: Active
✓ Membership: {years} year(s)

Your Account Information:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📧 Email: {user_data['email']}
👤 Username: {user_data['username']}
🏅 Rank: Scout

You Can Now Login!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Visit: {login_url}
Or go to: http://localhost:8000/accounts/login/

Use your email ({user_data['email']}) and the password you created during registration to login.

What's Next?
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Complete your profile
✓ Browse upcoming events
✓ Connect with other scouts
✓ Check announcements

Welcome to the ScoutConnect community! We're excited to have you on board.

If you have any questions, please don't hesitate to contact us.

Best regards,
The ScoutConnect Team

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This is an automated message. Please do not reply to this email.
'''

print("="*70)
print("📧 REGISTRATION CONFIRMATION EMAIL PREVIEW")
print("="*70)
print()
print(f"To: {user_data['email']}")
print(f"Subject: ✅ Registration Confirmed - Welcome to ScoutConnect!")
print()
print("Message Body:")
print("-"*70)
print(email_message)
print("-"*70)
print()
print("✅ This email will be sent automatically when payment is successful!")
print(f"✅ Recipient: {user_data['email']}")
print("✅ The user can login immediately after receiving this email")
print()
