This folder contains optional manual test helpers:

- test_notifications.py – Run from project root: `python scripts/test_notifications.py`
- test_twilio_api.py – Run from project root: `python scripts/test_twilio_api.py`

Both use environment variables for credentials and recipients. See `.env.example`.
