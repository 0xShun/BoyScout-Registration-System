#!/usr/bin/env python3
"""
Complete Payment Test with Real User Data
Tests the full PayMongo payment flow with webhook and email notifications
"""

import os
import sys
import django
from datetime import datetime

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'boyscout_system.settings')
django.setup()

from accounts.models import User, RegistrationPayment
from payments.services.paymongo_service import PayMongoService
from django.contrib.auth.hashers import make_password

def create_test_registration(user_data):
    """
    Create a test user and registration payment
    
    Args:
        user_data: Dictionary with user information
    """
    print("="*70)
    print("🧪 Creating Test Registration with Real User Data")
    print("="*70)
    
    # Check if user already exists
    existing_user = User.objects.filter(email=user_data['email']).first()
    if existing_user:
        print(f"\n⚠️  User already exists: {existing_user.email}")
        response = input("Delete existing user and create new? (y/n): ").strip().lower()
        if response == 'y':
            # Delete old registration payments first
            RegistrationPayment.objects.filter(user=existing_user).delete()
            existing_user.delete()
            print("✅ Old user deleted")
        else:
            print("❌ Cancelled. Using existing user.")
            return existing_user, None
    
    # Create user
    print(f"\n📝 Creating user account...")
    print(f"   Name: {user_data['first_name']} {user_data['last_name']}")
    print(f"   Email: {user_data['email']}")
    print(f"   Phone: {user_data['phone']}")
    print(f"   Birthday: {user_data['date_of_birth']}")
    print(f"   Address: {user_data['address']}")
    
    user = User.objects.create(
        username=user_data['email'].split('@')[0],
        email=user_data['email'],
        first_name=user_data['first_name'],
        last_name=user_data['last_name'],
        phone_number=user_data['phone'],
        date_of_birth=user_data['date_of_birth'],
        address=user_data['address'],
        password=make_password(user_data['password']),
        rank='scout',
        is_active=True,
        registration_status='pending',  # Will be activated after payment
    )
    
    print(f"\n✅ User created successfully!")
    print(f"   User ID: {user.id}")
    print(f"   Username: {user.username}")
    print(f"   Registration Status: {user.registration_status}")
    
    # Create registration payment
    print(f"\n💳 Creating registration payment...")
    registration_payment = RegistrationPayment.objects.create(
        user=user,
        amount=500.00,
        status='pending',
        notes='Test registration payment via PayMongo'
    )
    
    print(f"✅ Registration payment created!")
    print(f"   Payment ID: {registration_payment.id}")
    print(f"   Amount: ₱{registration_payment.amount}")
    print(f"   Status: {registration_payment.status}")
    
    return user, registration_payment


def create_paymongo_checkout(registration_payment, ngrok_url):
    """Create PayMongo source and checkout URL"""
    print("\n" + "="*70)
    print("💳 Creating PayMongo Checkout")
    print("="*70)
    
    try:
        # Create PayMongo source
        print("\n🔄 Calling PayMongo API...")
        
        source_data = PayMongoService.create_source(
            amount=registration_payment.amount,
            description=f'ScoutConnect Registration - {registration_payment.user.get_full_name()}',
            redirect_success=f'{ngrok_url}/payments/payment/success/',
            redirect_failed=f'{ngrok_url}/payments/payment/failed/',
            metadata={
                'payment_type': 'registration',
                'registration_payment_id': str(registration_payment.id),
                'user_id': str(registration_payment.user.id),
                'user_email': registration_payment.user.email,
            }
        )
        
        if source_data and source_data.get('success'):
            source_id = source_data['source_id']
            checkout_url = source_data['checkout_url']
            
            # Update registration payment with source ID
            registration_payment.paymongo_source_id = source_id
            registration_payment.save()
            
            print(f"\n✅ PayMongo Source Created Successfully!")
            print(f"   Source ID: {source_id}")
            print(f"   Status: {source_data.get('status', 'pending')}")
            print(f"   Type: {source_data.get('type', 'gcash')}")
            print(f"   Amount: ₱{source_data.get('amount', registration_payment.amount)}")
            
            return checkout_url, source_id
        else:
            print(f"\n❌ Failed to create PayMongo source")
            print(f"   Error: {source_data.get('error', 'Unknown error')}")
            return None, None
            
    except Exception as e:
        print(f"\n❌ Error creating PayMongo source: {str(e)}")
        return None, None


def main():
    print("\n" + "="*70)
    print("🎯 PayMongo Payment Test - Complete Flow")
    print("="*70)
    
    # Get user data
    print("\n📋 Please provide test user information:")
    print("   (This will create a real test account)")
    print()
    
    first_name = input("First Name: ").strip() or "Shawn"
    last_name = input("Last Name: ").strip() or "Sudaria"
    phone = input("Phone Number (09XXXXXXXXX): ").strip() or "09123456789"
    
    # Date of birth
    dob_input = input("Date of Birth (YYYY-MM-DD) or press Enter for 2000-01-01: ").strip()
    if dob_input:
        date_of_birth = dob_input
    else:
        date_of_birth = "2000-01-01"
    
    address = input("Address: ").strip() or "123 Test Street, Manila, Philippines"
    password = input("Password for test account: ").strip() or "TestPassword123"
    
    # Fixed email as requested
    email = "shawnmichaelsudaria14@gmail.com"
    
    user_data = {
        'first_name': first_name,
        'last_name': last_name,
        'email': email,
        'phone': phone,
        'date_of_birth': date_of_birth,
        'address': address,
        'password': password,
    }
    
    print(f"\n📧 Email will be sent to: {email}")
    print(f"🔐 Account password: {password}")
    
    # Check ngrok
    ngrok_url = "https://adelia-unsentimentalised-uncalamitously.ngrok-free.dev"
    print(f"\n🌐 Ngrok URL: {ngrok_url}")
    print(f"📊 Ngrok Inspector: http://127.0.0.1:4040/inspect/http")
    
    confirm = input("\n✅ Ready to create test registration? (y/n): ").strip().lower()
    if confirm != 'y':
        print("❌ Cancelled")
        return
    
    # Create test registration
    user, registration_payment = create_test_registration(user_data)
    
    if not registration_payment:
        print("\n❌ Could not create registration payment")
        return
    
    # Create PayMongo checkout
    checkout_url, source_id = create_paymongo_checkout(registration_payment, ngrok_url)
    
    if not checkout_url:
        print("\n❌ Could not create PayMongo checkout")
        return
    
    # Display summary
    print("\n" + "="*70)
    print("✅ Test Registration Created Successfully!")
    print("="*70)
    
    print(f"\n👤 Test User:")
    print(f"   Name: {user.get_full_name()}")
    print(f"   Email: {user.email}")
    print(f"   Username: {user.username}")
    print(f"   Password: {password}")
    print(f"   User ID: {user.id}")
    print(f"   Registration Status: {user.registration_status}")
    
    print(f"\n💳 Payment Details:")
    print(f"   Payment ID: {registration_payment.id}")
    print(f"   Amount: ₱{registration_payment.amount}")
    print(f"   Status: {registration_payment.status}")
    print(f"   Source ID: {source_id}")
    
    print(f"\n🔗 PayMongo Checkout URL:")
    print(f"   {checkout_url}")
    
    print(f"\n📊 Monitor Webhook:")
    print(f"   Ngrok Inspector: http://127.0.0.1:4040/inspect/http")
    print(f"   Watch for: POST /payments/paymongo/webhook/")
    
    print(f"\n📧 Email Notification:")
    print(f"   Will be sent to: {email}")
    print(f"   Subject: 'Registration Confirmed - ScoutConnect'")
    print(f"   Check inbox after completing payment")
    
    print("\n" + "="*70)
    print("📝 Next Steps:")
    print("="*70)
    print("1. Open PayMongo checkout in browser (opening now...)")
    print("2. Complete payment using test payment method")
    print("3. Watch ngrok inspector for webhook request")
    print("4. Check email inbox for confirmation")
    print("5. Try logging in with the credentials above")
    
    print("\n🔍 What to Check:")
    print("   ✅ Ngrok shows POST /payments/paymongo/webhook/ (200 OK)")
    print("   ✅ Email arrives at shawnmichaelsudaria14@gmail.com")
    print("   ✅ User registration_status changes to 'active'")
    print("   ✅ Can login with username and password")
    
    # Save checkout URL
    with open('/tmp/paymongo_checkout_url.txt', 'w') as f:
        f.write(checkout_url)
    
    print(f"\n💾 Checkout URL saved to: /tmp/paymongo_checkout_url.txt")
    
    # Open in browser
    print("\n🌐 Opening PayMongo checkout in browser...")
    import webbrowser
    try:
        webbrowser.open(checkout_url)
        print("✅ Browser opened")
    except:
        print("⚠️  Could not open browser automatically")
        print(f"   Please open manually: {checkout_url}")
    
    print("\n🎉 Test setup complete! Complete the payment to test the full flow.\n")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n❌ Test cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
