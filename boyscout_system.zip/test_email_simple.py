#!/usr/bin/env python3
"""
Quick Email Test Script for ScoutConnect
Tests if Gmail SMTP is configured correctly
"""

import os
import sys
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'boyscout_system.settings')
django.setup()

from django.core.mail import send_mail
from django.conf import settings
from notifications.services import NotificationService

print("="*60)
print("📧 Email Configuration Test")
print("="*60)

# Show configuration
print(f"\n✅ Email Backend: {settings.EMAIL_BACKEND}")
print(f"✅ SMTP Host: {settings.EMAIL_HOST}:{settings.EMAIL_PORT}")
print(f"✅ Email User: {settings.EMAIL_HOST_USER}")
print(f"✅ Password: {'*' * len(settings.EMAIL_HOST_PASSWORD)} (length: {len(settings.EMAIL_HOST_PASSWORD)})")
print(f"✅ From Email: {settings.DEFAULT_FROM_EMAIL}")
print(f"✅ TLS Enabled: {settings.EMAIL_USE_TLS}")

# Test email sending
print("\n" + "="*60)
print("🧪 Sending Test Email...")
print("="*60)

try:
    # Test recipient email
    test_recipient = 'shawnmichaelsudaria14@gmail.com'
    
    # Method 1: Using Django's send_mail
    result = send_mail(
        subject='✅ ScoutConnect Email Test - Success!',
        message='''
Hello!

This is a test email from ScoutConnect.

If you're reading this, your email configuration is working perfectly! 🎉

✅ Gmail SMTP is configured correctly
✅ App Password is valid
✅ Email notifications are ready

Next steps:
1. Test payment flow: .venv/bin/python test_registration_flow.py --type single
2. Complete payment on PayMongo
3. Check for automatic confirmation email

---
ScoutConnect Notification System
        ''',
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[test_recipient],
        fail_silently=False,
    )
    
    if result == 1:
        print(f"\n✅ SUCCESS! Test email sent to: {test_recipient}")
        print(f"📬 Check your Gmail inbox: {test_recipient}")
        print("   (Don't forget to check spam folder if you don't see it)")
        print("\n" + "="*60)
        print("🎉 Email Notifications Are Ready!")
        print("="*60)
        print("\n📋 What happens now:")
        print("   • Registration payment confirmed → User gets email")
        print("   • Batch registration complete → Teacher gets email")
        print("   • Each student → Gets welcome email")
        print("   • Event notifications → Automatic emails")
        print("\n🧪 Test the full flow:")
        print("   .venv/bin/python test_registration_flow.py --type single")
    else:
        print("\n❌ Email sending failed (returned 0)")
        
except Exception as e:
    print(f"\n❌ ERROR: {str(e)}")
    print("\n🔧 Troubleshooting:")
    print("   1. Verify App Password is correct (16 characters, no spaces)")
    print("   2. Make sure 2-Factor Authentication is enabled on Gmail")
    print("   3. Check if Gmail is blocking the login")
    print("   4. Visit: https://myaccount.google.com/security")
    print("   5. See EMAIL_SETUP_GUIDE.md for detailed help")
    sys.exit(1)

print("\n✅ Email setup complete! Ready to test payment notifications.\n")
