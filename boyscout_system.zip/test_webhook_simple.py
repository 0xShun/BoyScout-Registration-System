#!/usr/bin/env python
"""
Simple webhook test - tests webhook processing without signature
For development/testing only!
"""

import requests
import json

WEBHOOK_URL = "http://localhost:8000/payments/webhook/"

# Test payload for payment.paid event
test_payload = {
    "data": {
        "id": "evt_test_123",
        "type": "event",
        "attributes": {
            "type": "payment.paid",
            "livemode": False,
            "data": {
                "id": "pay_test_12345",
                "type": "payment",
                "attributes": {
                    "amount": 50000,
                    "currency": "PHP",
                    "status": "paid",
                    "source": {
                        "id": "src_test_67890",
                        "type": "source"
                    }
                }
            }
        }
    }
}

print("=" * 60)
print("Testing Webhook Endpoint")
print("=" * 60)
print(f"\nEndpoint: {WEBHOOK_URL}")
print(f"Event: payment.paid")
print("\nNote: This will fail signature verification (expected)")
print("Real PayMongo webhooks will have valid signatures")

try:
    response = requests.post(
        WEBHOOK_URL,
        json=test_payload,
        headers={'Content-Type': 'application/json'},
        timeout=5
    )
    
    print(f"\n✅ Webhook endpoint is accessible!")
    print(f"Response: {response.status_code}")
    print(f"Body: {response.text}")
    
    if response.status_code == 401:
        print("\n✅ Signature verification is working (rejected test payload)")
        print("This is GOOD - it means your webhook is secure!")
        
except requests.exceptions.ConnectionError:
    print("\n❌ Cannot connect to Django server")
    print("Make sure Django is running: .venv/bin/python manage.py runserver")
    
except Exception as e:
    print(f"\n❌ Error: {e}")

print("\n" + "=" * 60)
print("Next Steps:")
print("=" * 60)
print("1. Your webhook endpoint is working ✓")
print("2. Signature verification is active ✓")
print("3. Go to PayMongo Dashboard and send a test event")
print("4. Or create a real payment to test end-to-end")
