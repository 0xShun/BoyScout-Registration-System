#!/usr/bin/env python
"""
Test Event QR PH Integration
Tests the complete flow of event registration with PayMongo QR PH payment.
"""
import os
import django
import sys

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'boyscout_system.settings')
django.setup()

from django.contrib.auth import get_user_model
from events.models import Event, EventRegistration, EventPayment
from payments.services.paymongo_service import PayMongoService
from datetime import date, time
from decimal import Decimal

User = get_user_model()

def print_header(text):
    """Print formatted header"""
    print("\n" + "="*60)
    print(f"  {text}")
    print("="*60)

def print_success(text):
    """Print success message"""
    print(f"✅ {text}")

def print_error(text):
    """Print error message"""
    print(f"❌ {text}")

def print_info(text):
    """Print info message"""
    print(f"ℹ️  {text}")

def test_paymongo_connection():
    """Test PayMongo API connection"""
    print_header("Testing PayMongo Connection")
    
    try:
        paymongo = PayMongoService()
        print_success("PayMongo service initialized")
        print_info(f"Using API key: {paymongo.secret_key[:10]}...")
        return True
    except Exception as e:
        print_error(f"Failed to initialize PayMongo: {str(e)}")
        return False

def test_event_model():
    """Test Event model changes"""
    print_header("Testing Event Model")
    
    # Check if qr_code field is removed
    from django.core.exceptions import FieldDoesNotExist
    try:
        Event._meta.get_field('qr_code')
        print_error("Event.qr_code field still exists (should be removed)")
        return False
    except FieldDoesNotExist:
        print_success("Event.qr_code field successfully removed")
    
    # Check if payment_amount field exists
    try:
        payment_field = Event._meta.get_field('payment_amount')
        print_success(f"Event.payment_amount field exists ({payment_field.get_internal_type()})")
    except FieldDoesNotExist:
        print_error("Event.payment_amount field missing")
        return False
    
    return True

def test_event_payment_model():
    """Test EventPayment model changes"""
    print_header("Testing EventPayment Model")
    
    required_fields = ['paymongo_source_id', 'paymongo_payment_id', 'payment_method']
    
    for field_name in required_fields:
        try:
            field = EventPayment._meta.get_field(field_name)
            print_success(f"EventPayment.{field_name} field exists ({field.get_internal_type()})")
        except Exception as e:
            print_error(f"EventPayment.{field_name} field missing: {str(e)}")
            return False
    
    return True

def test_create_test_event():
    """Create a test paid event"""
    print_header("Creating Test Event")
    
    try:
        # Get or create admin user
        admin = User.objects.filter(rank='admin').first()
        if not admin:
            print_error("No admin user found. Create an admin first.")
            return None
        
        print_info(f"Using admin: {admin.username}")
        
        # Create test event
        event = Event.objects.create(
            title="Test QR PH Event",
            description="Test event for QR PH payment integration",
            date=date(2024, 12, 31),
            time=time(14, 0),
            location="Test Location",
            payment_amount=Decimal('300.00'),
            created_by=admin
        )
        
        print_success(f"Created test event: {event.title} (ID: {event.pk})")
        print_info(f"Payment amount: ₱{event.payment_amount}")
        print_info(f"Has payment required: {event.has_payment_required}")
        
        return event
        
    except Exception as e:
        print_error(f"Failed to create test event: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def test_registration_flow(event):
    """Test event registration flow"""
    print_header("Testing Registration Flow")
    
    try:
        # Get a test scout user
        scout = User.objects.filter(rank='scout').exclude(
            event_registrations__event=event
        ).first()
        
        if not scout:
            print_error("No scout user available for testing")
            return False
        
        print_info(f"Using scout: {scout.username}")
        
        # Create registration
        registration = EventRegistration.objects.create(
            event=event,
            user=scout,
            rsvp='yes'
        )
        print_success(f"Created event registration (ID: {registration.pk})")
        
        # Test PayMongo source creation
        print_info("Creating PayMongo payment source...")
        paymongo = PayMongoService()
        
        success, response = paymongo.create_source(
            amount=event.payment_amount,
            description=f"Event Registration: {event.title}",
            redirect_success=f"http://localhost:8000/events/{event.pk}/",
            redirect_failed=f"http://localhost:8000/events/{event.pk}/",
            metadata={
                'payment_type': 'event_registration',
                'event_id': str(event.pk),
                'event_registration_id': str(registration.pk),
                'user_id': str(scout.pk),
                'event_title': event.title,
            }
        )
        
        if success and 'data' in response:
            source_data = response['data']
            source_id = source_data['id']
            checkout_url = source_data['attributes']['redirect']['checkout_url']
            
            print_success(f"PayMongo source created: {source_id}")
            print_info(f"Checkout URL: {checkout_url}")
            
            # Create EventPayment record
            event_payment = EventPayment.objects.create(
                registration=registration,
                amount=event.payment_amount,
                status='pending',
                payment_method='qr_ph',
                paymongo_source_id=source_id,
                notes=f"PayMongo QR PH payment for {event.title}"
            )
            print_success(f"Created EventPayment record (ID: {event_payment.pk})")
            
            print_info("\nTo test payment:")
            print_info(f"1. Open: {checkout_url}")
            print_info("2. Scan QR code with PayMongo test app")
            print_info("3. Complete payment")
            print_info("4. Webhook should auto-verify")
            
            # Clean up
            print_info("\nCleaning up test records...")
            event_payment.delete()
            registration.delete()
            print_success("Test records cleaned up")
            
            return True
        else:
            print_error(f"PayMongo source creation failed: {response}")
            registration.delete()
            return False
            
    except Exception as e:
        print_error(f"Registration flow test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_free_event():
    """Test free event registration"""
    print_header("Testing Free Event Registration")
    
    try:
        # Get admin
        admin = User.objects.filter(rank='admin').first()
        
        # Create free event
        free_event = Event.objects.create(
            title="Test Free Event",
            description="Free event with no payment required",
            date=date(2024, 12, 31),
            time=time(10, 0),
            location="Test Location",
            payment_amount=Decimal('0.00'),
            created_by=admin
        )
        
        print_success(f"Created free event: {free_event.title}")
        print_info(f"Has payment required: {free_event.has_payment_required}")
        
        # Test registration
        scout = User.objects.filter(rank='scout').first()
        registration = EventRegistration.objects.create(
            event=free_event,
            user=scout,
            rsvp='yes',
            payment_status='not_required',
            verified=True
        )
        
        print_success("Free event registration created")
        print_info(f"Payment status: {registration.payment_status}")
        print_info(f"Verified: {registration.verified}")
        
        # Clean up
        registration.delete()
        free_event.delete()
        print_success("Free event test completed and cleaned up")
        
        return True
        
    except Exception as e:
        print_error(f"Free event test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print_header("Event QR PH Integration Test Suite")
    print_info("Testing complete event payment flow with PayMongo QR PH")
    
    results = {
        'PayMongo Connection': test_paymongo_connection(),
        'Event Model': test_event_model(),
        'EventPayment Model': test_event_payment_model(),
    }
    
    # Create test event for flow testing
    test_event = test_create_test_event()
    if test_event:
        results['Registration Flow'] = test_registration_flow(test_event)
        results['Free Event'] = test_free_event()
        
        # Clean up test event
        print_header("Cleanup")
        test_event.delete()
        print_success("Test event deleted")
    else:
        results['Registration Flow'] = False
        results['Free Event'] = False
    
    # Print summary
    print_header("Test Summary")
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print_success("\n🎉 All tests passed! QR PH integration is working correctly.")
        print_info("\nNext steps:")
        print_info("1. Test complete flow in browser at http://localhost:8000/events/")
        print_info("2. Create a paid event as admin")
        print_info("3. Register as scout user and complete PayMongo payment")
        print_info("4. Verify webhook auto-verifies the payment")
    else:
        print_error(f"\n⚠️  {total - passed} test(s) failed. Review errors above.")
    
    return passed == total

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
