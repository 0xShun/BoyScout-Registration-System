#!/usr/bin/env python
"""
Quick test script for Phase 1 QR PH and PayMongo integration
Run this to verify the service layer is working correctly
"""

import os
import sys
import django

# Add the project directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'boyscout_system.settings')
django.setup()

from decimal import Decimal
from payments.services import QRPHService, PayMongoService

def test_qr_ph_service():
    """Test QR PH service functionality"""
    print("=" * 60)
    print("Testing QR PH Service")
    print("=" * 60)
    
    try:
        # Test 1: Generate static QR code (no amount)
        print("\n1. Testing static QR code generation...")
        qr_string, qr_image = QRPHService.create_payment_qr_code(
            merchant_id="SCOUT001",
            merchant_name="ScoutConnect",
            account_number="09171234567"
        )
        print(f"✅ Static QR string generated (length: {len(qr_string)})")
        print(f"   Preview: {qr_string[:100]}...")
        print(f"✅ QR image generated ({len(qr_image.read())} bytes)")
        
        # Test 2: Generate dynamic QR code (with amount)
        print("\n2. Testing dynamic QR code generation...")
        qr_string, qr_image = QRPHService.create_payment_qr_code(
            merchant_id="SCOUT001",
            merchant_name="ScoutConnect",
            account_number="09171234567",
            amount=Decimal("500.00"),
            reference="PAY-TEST-001"
        )
        print(f"✅ Dynamic QR string generated (length: {len(qr_string)})")
        print(f"   Preview: {qr_string[:100]}...")
        print(f"✅ QR image generated ({len(qr_image.read())} bytes)")
        
        # Test 3: Verify CRC calculation
        print("\n3. Testing CRC checksum calculation...")
        test_data = "000201010212"
        crc = QRPHService._calculate_crc16_ccitt(test_data + "6304")
        print(f"✅ CRC calculated: {crc}")
        
        print("\n✅ All QR PH Service tests passed!")
        return True
        
    except Exception as e:
        print(f"\n❌ QR PH Service test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_paymongo_service():
    """Test PayMongo service functionality"""
    print("\n" + "=" * 60)
    print("Testing PayMongo Service")
    print("=" * 60)
    
    try:
        # Initialize service
        paymongo = PayMongoService()
        
        # Check if API keys are configured
        if not paymongo.secret_key:
            print("\n⚠️  PayMongo API keys not configured")
            print("   Set PAYMONGO_SECRET_KEY in your .env file to test API calls")
            print("   Service initialization: ✅ OK")
            return True
        
        print("\n1. Testing PayMongo API connection...")
        print(f"   Public Key: {paymongo.public_key[:20]}...")
        print(f"   Secret Key: {paymongo.secret_key[:20]}...")
        
        # Test creating a source (this will fail without valid keys)
        success, response = paymongo.create_source(
            amount=Decimal("100.00"),
            description="Test Payment",
            redirect_success="http://localhost:8000/success/",
            redirect_failed="http://localhost:8000/failed/",
            metadata={"test": True}
        )
        
        if success:
            print(f"✅ PayMongo API connection successful!")
            print(f"   Source ID: {response['data']['id']}")
        else:
            print(f"⚠️  PayMongo API call failed (this is expected with test/invalid keys)")
            print(f"   Error: {response}")
        
        print("\n✅ PayMongo Service tests passed!")
        return True
        
    except Exception as e:
        print(f"\n❌ PayMongo Service test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_models():
    """Test that models import correctly"""
    print("\n" + "=" * 60)
    print("Testing Models")
    print("=" * 60)
    
    try:
        from payments.models import Payment, PaymentQRCode
        
        print("\n1. Checking Payment model fields...")
        payment_fields = [f.name for f in Payment._meta.get_fields()]
        required_fields = [
            'payment_method', 'qr_ph_reference', 'paymongo_payment_intent_id',
            'paymongo_payment_id', 'paymongo_source_id', 'gateway_response',
            'receipt_image'
        ]
        
        for field in required_fields:
            if field in payment_fields:
                print(f"   ✅ {field}")
            else:
                print(f"   ❌ {field} - MISSING!")
                return False
        
        print("\n2. Checking PaymentQRCode model fields...")
        qr_fields = [f.name for f in PaymentQRCode._meta.get_fields()]
        required_qr_fields = [
            'qr_ph_string', 'merchant_id', 'merchant_name', 'account_number',
            'gateway_provider', 'paymongo_public_key', 'paymongo_secret_key',
            'paymongo_webhook_secret'
        ]
        
        for field in required_qr_fields:
            if field in qr_fields:
                print(f"   ✅ {field}")
            else:
                print(f"   ❌ {field} - MISSING!")
                return False
        
        print("\n✅ All model fields present!")
        return True
        
    except Exception as e:
        print(f"\n❌ Model test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("\n" + "=" * 60)
    print("PHASE 1 INTEGRATION TEST SUITE")
    print("QR PH & PayMongo Integration")
    print("=" * 60)
    
    results = {
        'Models': test_models(),
        'QR PH Service': test_qr_ph_service(),
        'PayMongo Service': test_paymongo_service(),
    }
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name}: {status}")
    
    all_passed = all(results.values())
    
    if all_passed:
        print("\n🎉 All tests passed! Phase 1 implementation is working correctly.")
        print("\nNext steps:")
        print("1. Configure PayMongo API keys in .env file")
        print("2. Proceed with Phase 2 implementation")
        print("3. Update views and templates")
    else:
        print("\n⚠️  Some tests failed. Please review the errors above.")
        print("Check that:")
        print("- Migrations have been applied")
        print("- All dependencies are installed")
        print("- Django settings are correct")
    
    return 0 if all_passed else 1

if __name__ == '__main__':
    sys.exit(main())
