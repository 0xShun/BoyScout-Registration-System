#!/usr/bin/env python
"""
Test PayMongo webhook locally
Sends a test webhook payload to your local webhook endpoint
"""

import requests
import json
import hmac
import hashlib
import time

# Your webhook URL (change if using ngrok)
WEBHOOK_URL = "http://localhost:8000/payments/webhook/"

# Your webhook secret from .env
WEBHOOK_SECRET = "whsk_1KbbUDraJMEgVfiVpVvfyaaE"

# Test payload - simulating a payment.paid event
test_payload = {
    "data": {
        "id": "evt_test_123",
        "type": "event",
        "attributes": {
            "type": "payment.paid",
            "livemode": False,
            "data": {
                "id": "pay_test_123",
                "type": "payment",
                "attributes": {
                    "amount": 50000,  # ₱500.00 in centavos
                    "currency": "PHP",
                    "status": "paid",
                    "source": {
                        "id": "src_test_123",
                        "type": "source"
                    }
                }
            },
            "created_at": int(time.time()),
            "updated_at": int(time.time())
        }
    }
}

def generate_signature(payload_string, secret):
    """Generate PayMongo webhook signature"""
    timestamp = str(int(time.time()))
    signed_payload = f"{timestamp}.{payload_string}"
    
    signature = hmac.new(
        secret.encode(),
        signed_payload.encode(),
        hashlib.sha256
    ).hexdigest()
    
    # PayMongo uses 'li' for live and 'test_li' for test
    return f"t={timestamp},li={signature}"

def test_webhook():
    """Send test webhook to local endpoint"""
    payload_string = json.dumps(test_payload)
    signature = generate_signature(payload_string, WEBHOOK_SECRET)
    
    headers = {
        'Content-Type': 'application/json',
        'Paymongo-Signature': signature
    }
    
    print("=" * 60)
    print("Testing PayMongo Webhook")
    print("=" * 60)
    print(f"\nWebhook URL: {WEBHOOK_URL}")
    print(f"Event Type: payment.paid")
    print(f"Payload:\n{json.dumps(test_payload, indent=2)}")
    print(f"\nSignature: {signature[:50]}...")
    
    try:
        print("\nSending webhook...")
        response = requests.post(
            WEBHOOK_URL,
            json=test_payload,
            headers=headers,
            timeout=10
        )
        
        print(f"\n✅ Response Status: {response.status_code}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            print("\n🎉 Webhook test successful!")
        else:
            print(f"\n⚠️  Webhook returned status {response.status_code}")
            
    except requests.exceptions.ConnectionError:
        print("\n❌ Connection failed! Is Django server running?")
        print("   Start server with: .venv/bin/python manage.py runserver")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")

if __name__ == '__main__':
    test_webhook()
