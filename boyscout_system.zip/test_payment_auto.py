#!/usr/bin/env python3
"""
Automated Payment Test - Uses shawnmichaelsudaria14@gmail.com
No user input required - runs automatically with default test data
"""

import os
import sys
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'boyscout_system.settings')
django.setup()

from accounts.models import User, RegistrationPayment
from payments.services.paymongo_service import PayMongoService
from django.contrib.auth.hashers import make_password

# FIXED USER DATA - Using your email
USER_DATA = {
    'first_name': 'Shawn',
    'last_name': 'Sudaria',
    'email': 'shawnmichaelsudaria14@gmail.com',  # YOUR EMAIL
    'phone': '+639123456789',
    'date_of_birth': '2000-05-15',
    'address': 'Manila, Philippines',
    'password': 'TestPassword123',
}

NGROK_URL = 'https://adelia-unsentimentalised-uncalamitously.ngrok-free.dev'

print("="*70)
print("🧪 Automated Payment Test")
print("="*70)
print(f"\n📧 Email: {USER_DATA['email']}")
print(f"👤 Name: {USER_DATA['first_name']} {USER_DATA['last_name']}")
print(f"🔐 Password: {USER_DATA['password']}")
print(f"🌐 Ngrok: {NGROK_URL}")
print(f"📊 Inspector: http://127.0.0.1:4040/inspect/http")

# Check if user exists
existing_user = User.objects.filter(email=USER_DATA['email']).first()
if existing_user:
    print(f"\n⚠️  User already exists (ID: {existing_user.id})")
    print("   Deleting old user and creating fresh...")
    RegistrationPayment.objects.filter(user=existing_user).delete()
    existing_user.delete()
    print("   ✅ Old user deleted")

# Create user
print(f"\n📝 Creating test user...")
user = User.objects.create(
    username='shawnsudaria',
    email=USER_DATA['email'],
    first_name=USER_DATA['first_name'],
    last_name=USER_DATA['last_name'],
    phone_number=USER_DATA['phone'],
    date_of_birth=USER_DATA['date_of_birth'],
    address=USER_DATA['address'],
    password=make_password(USER_DATA['password']),
    rank='scout',
    is_active=True,
    registration_status='pending',
)

print(f"✅ User created!")
print(f"   User ID: {user.id}")
print(f"   Email: {user.email}")
print(f"   Status: {user.registration_status}")

# Create registration payment
print(f"\n💳 Creating registration payment...")
registration_payment = RegistrationPayment.objects.create(
    user=user,
    amount=500.00,
    status='pending',
    notes='Automated test payment'
)

print(f"✅ Payment created!")
print(f"   Payment ID: {registration_payment.id}")
print(f"   Amount: ₱{registration_payment.amount}")

# Create PayMongo source
print(f"\n🔄 Creating PayMongo checkout...")
try:
    paymongo_service = PayMongoService()
    success, source_response = paymongo_service.create_source(
        amount=registration_payment.amount,
        description=f'ScoutConnect Registration - {user.get_full_name()}',
        redirect_success=f'{NGROK_URL}/payments/success/',
        redirect_failed=f'{NGROK_URL}/payments/failed/',
        metadata={
            'payment_type': 'registration',
            'registration_payment_id': str(registration_payment.id),
            'user_id': str(user.id),
            'user_email': user.email,
        }
    )
    
    if success and source_response:
        # Extract source data from response
        source_data = source_response.get('data', {})
        source_id = source_data.get('id')
        source_attributes = source_data.get('attributes', {})
        checkout_url = source_attributes.get('redirect', {}).get('checkout_url')
        
        # Update payment
        registration_payment.paymongo_source_id = source_id
        registration_payment.save()
        
        print(f"✅ PayMongo checkout created!")
        print(f"   Source ID: {source_id}")
        print(f"   Amount: ₱{source_attributes.get('amount', 50000) / 100}")
        
        # Display results
        print("\n" + "="*70)
        print("✅ TEST REGISTRATION READY!")
        print("="*70)
        
        print(f"\n👤 Login Credentials:")
        print(f"   Email: {user.email}")
        print(f"   Username: {user.username}")
        print(f"   Password: {USER_DATA['password']}")
        print(f"   User ID: {user.id}")
        
        print(f"\n💳 Payment:")
        print(f"   Payment ID: {registration_payment.id}")
        print(f"   Amount: ₱{registration_payment.amount}")
        print(f"   Status: {registration_payment.status}")
        print(f"   Source: {source_id}")
        
        print(f"\n🔗 PayMongo Checkout:")
        print(f"   {checkout_url}")
        
        print("\n📊 Monitor Webhook at:")
        print(f"   http://127.0.0.1:4040/inspect/http")
        print(f"   Look for: POST /payments/paymongo/webhook/")
        
        print("\n📧 Email will be sent to:")
        print(f"   {USER_DATA['email']}")
        print(f"   Subject: 'Registration Confirmed - ScoutConnect'")
        
        print("\n" + "="*70)
        print("📝 TESTING CHECKLIST:")
        print("="*70)
        print("1. ✅ Test user created")
        print("2. ✅ Registration payment created")
        print("3. ✅ PayMongo checkout URL generated")
        print("4. ⏳ Complete payment on PayMongo (opening now...)")
        print("5. ⏳ Watch ngrok inspector for webhook")
        print("6. ⏳ Check email inbox")
        print("7. ⏳ Verify user status changes to 'active'")
        print("8. ⏳ Try logging in")
        
        # Save URL
        with open('/tmp/paymongo_checkout_url.txt', 'w') as f:
            f.write(checkout_url)
        print(f"\n💾 Checkout URL saved to: /tmp/paymongo_checkout_url.txt")
        
        # Open browser
        print("\n🌐 Opening PayMongo checkout...")
        import webbrowser
        try:
            webbrowser.open(checkout_url)
            print("✅ Browser opened - complete the payment!")
        except:
            print("⚠️  Please open manually:")
            print(f"   {checkout_url}")
        
        print("\n🎉 Ready! Complete payment and watch for:")
        print("   • Webhook request in ngrok inspector")
        print(f"   • Email to {USER_DATA['email']}")
        print("   • User activation in database")
        print()
        
    else:
        print(f"❌ Failed to create PayMongo source")
        print(f"   Error: {source_response.get('error', 'Unknown')}")
        
except Exception as e:
    print(f"❌ Error: {str(e)}")
    import traceback
    traceback.print_exc()
