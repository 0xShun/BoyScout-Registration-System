#!/usr/bin/env python
"""
Research Metrics Collection Script
Collects all metrics for research paper results section
"""
import os
import django
import json
from decimal import Decimal
from datetime import datetime, timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'boyscout_system.settings')
django.setup()

from django.db.models import Count, Sum, Avg, Q, F
from django.utils import timezone
from accounts.models import User
from payments.models import Payment
from events.models import Event, EventRegistration, EventPayment, Attendance
from announcements.models import Announcement

def collect_metrics():
    """Collect all metrics for research results"""
    
    print("=" * 80)
    print("COLLECTING METRICS FOR RESEARCH RESULTS")
    print("=" * 80)
    
    metrics = {}
    
    # ========== OBJECTIVE 1: DATA DASHBOARDS ==========
    print("\n📊 OBJECTIVE 1: DATA DASHBOARDS FOR REAL-TIME INSIGHTS")
    print("-" * 80)
    
    # Membership Metrics
    total_users = User.objects.count()
    active_scouts = User.objects.filter(registration_status='active', rank='scout').count()
    pending_scouts = User.objects.filter(registration_status='pending_payment', rank='scout').count()
    inactive_scouts = User.objects.filter(registration_status='inactive', rank='scout').count()
    admin_count = User.objects.filter(rank='admin').count()
    
    print(f"✓ Total Users: {total_users}")
    print(f"✓ Active Scouts: {active_scouts}")
    print(f"✓ Pending Scouts: {pending_scouts}")
    print(f"✓ Inactive Scouts: {inactive_scouts}")
    print(f"✓ Administrators: {admin_count}")
    
    metrics['membership'] = {
        'total_users': total_users,
        'active_scouts': active_scouts,
        'pending_scouts': pending_scouts,
        'inactive_scouts': inactive_scouts,
        'admin_count': admin_count,
        'active_percentage': round((active_scouts / total_users * 100) if total_users > 0 else 0, 2)
    }
    
    # Payment Metrics
    total_payments = Payment.objects.count()
    verified_payments = Payment.objects.filter(status='verified').count()
    pending_payments = Payment.objects.filter(status__in=['pending', 'for_verification']).count()
    failed_payments = Payment.objects.filter(status='failed').count()
    
    payment_revenue = Payment.objects.filter(status='verified').aggregate(
        total=Sum('amount')
    )['total'] or Decimal('0')
    
    avg_payment = Payment.objects.filter(status='verified').aggregate(
        avg=Avg('amount')
    )['avg'] or Decimal('0')
    
    success_rate = round((verified_payments / total_payments * 100) if total_payments > 0 else 0, 2)
    
    # PayMongo specific metrics
    paymongo_payments = Payment.objects.filter(payment_method='qr_ph').count()
    paymongo_verified = Payment.objects.filter(payment_method='qr_ph', status='verified').count()
    paymongo_rate = round((paymongo_verified / paymongo_payments * 100) if paymongo_payments > 0 else 0, 2)
    
    print(f"\n💰 Payment Analytics:")
    print(f"✓ Total Payments: {total_payments}")
    print(f"✓ Verified Payments: {verified_payments}")
    print(f"✓ Pending Payments: {pending_payments}")
    print(f"✓ Failed Payments: {failed_payments}")
    print(f"✓ Total Revenue: ₱{payment_revenue:,.2f}")
    print(f"✓ Average Payment: ₱{avg_payment:,.2f}")
    print(f"✓ Success Rate: {success_rate}%")
    print(f"✓ PayMongo QR PH Payments: {paymongo_payments}")
    print(f"✓ PayMongo Success Rate: {paymongo_rate}%")
    
    metrics['payments'] = {
        'total_payments': total_payments,
        'verified_payments': verified_payments,
        'pending_payments': pending_payments,
        'failed_payments': failed_payments,
        'total_revenue': float(payment_revenue),
        'average_payment': float(avg_payment),
        'success_rate': success_rate,
        'paymongo_payments': paymongo_payments,
        'paymongo_verified': paymongo_verified,
        'paymongo_success_rate': paymongo_rate
    }
    
    # Event Participation Metrics
    total_events = Event.objects.count()
    upcoming_events = Event.objects.filter(date__gte=timezone.now().date()).count()
    past_events = Event.objects.filter(date__lt=timezone.now().date()).count()
    
    total_registrations = EventRegistration.objects.count()
    paid_registrations = EventRegistration.objects.filter(payment_status='paid').count()
    pending_event_payments = EventRegistration.objects.filter(payment_status='pending').count()
    free_registrations = EventRegistration.objects.filter(payment_status='not_required').count()
    
    avg_registrations_per_event = round(total_registrations / total_events if total_events > 0 else 0, 2)
    
    event_revenue = EventPayment.objects.filter(status='completed').aggregate(
        total=Sum('amount')
    )['total'] or Decimal('0')
    
    # Event payment method breakdown
    event_qr_payments = EventPayment.objects.filter(payment_method='qr_ph').count()
    
    print(f"\n📅 Event Participation:")
    print(f"✓ Total Events: {total_events}")
    print(f"✓ Upcoming Events: {upcoming_events}")
    print(f"✓ Past Events: {past_events}")
    print(f"✓ Total Registrations: {total_registrations}")
    print(f"✓ Paid Registrations: {paid_registrations}")
    print(f"✓ Free Registrations: {free_registrations}")
    print(f"✓ Pending Event Payments: {pending_event_payments}")
    print(f"✓ Avg Registrations/Event: {avg_registrations_per_event}")
    print(f"✓ Event Revenue: ₱{event_revenue:,.2f}")
    print(f"✓ QR PH Event Payments: {event_qr_payments}")
    
    metrics['events'] = {
        'total_events': total_events,
        'upcoming_events': upcoming_events,
        'past_events': past_events,
        'total_registrations': total_registrations,
        'paid_registrations': paid_registrations,
        'free_registrations': free_registrations,
        'pending_event_payments': pending_event_payments,
        'avg_registrations_per_event': avg_registrations_per_event,
        'event_revenue': float(event_revenue),
        'event_qr_payments': event_qr_payments
    }
    
    # Attendance Metrics
    total_attendance_records = Attendance.objects.count()
    present_count = Attendance.objects.filter(status='present').count()
    absent_count = Attendance.objects.filter(status='absent').count()
    excused_count = Attendance.objects.filter(status='excused').count()
    
    attendance_rate = round((present_count / total_attendance_records * 100) if total_attendance_records > 0 else 0, 2)
    
    print(f"\n📋 Attendance Tracking:")
    print(f"✓ Total Attendance Records: {total_attendance_records}")
    print(f"✓ Present: {present_count}")
    print(f"✓ Absent: {absent_count}")
    print(f"✓ Excused: {excused_count}")
    print(f"✓ Attendance Rate: {attendance_rate}%")
    
    metrics['attendance'] = {
        'total_records': total_attendance_records,
        'present': present_count,
        'absent': absent_count,
        'excused': excused_count,
        'attendance_rate': attendance_rate
    }
    
    # ========== OBJECTIVE 2: ANNOUNCEMENTS ==========
    print("\n" + "=" * 80)
    print("📢 OBJECTIVE 2: ANNOUNCEMENT SYSTEM")
    print("-" * 80)
    
    total_announcements = Announcement.objects.count()
    
    # Calculate engagement
    announcement_data = []
    total_reads = 0
    total_recipients = 0
    
    for announcement in Announcement.objects.all():
        reads = announcement.read_by.count()
        recipients = announcement.recipients.count()
        total_reads += reads
        total_recipients += recipients
        
        read_rate = round((reads / recipients * 100) if recipients > 0 else 0, 2)
        announcement_data.append({
            'title': announcement.title[:50],
            'reads': reads,
            'recipients': recipients,
            'read_rate': read_rate,
            'date': announcement.date_posted.strftime('%Y-%m-%d') if announcement.date_posted else 'N/A'
        })
    
    avg_read_rate = round((total_reads / total_recipients * 100) if total_recipients > 0 else 0, 2)
    
    print(f"✓ Total Announcements Posted: {total_announcements}")
    print(f"✓ Total Reads: {total_reads}")
    print(f"✓ Total Recipients: {total_recipients}")
    print(f"✓ Average Read Rate: {avg_read_rate}%")
    
    metrics['announcements'] = {
        'total_announcements': total_announcements,
        'total_reads': total_reads,
        'total_recipients': total_recipients,
        'average_read_rate': avg_read_rate,
        'announcement_details': sorted(announcement_data, key=lambda x: x['read_rate'], reverse=True)
    }
    
    # ========== OBJECTIVE 3: CALENDAR MODULE ==========
    print("\n" + "=" * 80)
    print("📆 OBJECTIVE 3: CALENDAR MODULE")
    print("-" * 80)
    
    # Event type breakdown
    paid_events = Event.objects.filter(payment_amount__gt=0).count()
    free_events = Event.objects.filter(payment_amount=0).count()
    
    # Monthly event distribution (last 6 months)
    six_months_ago = timezone.now().date() - timedelta(days=180)
    recent_events = Event.objects.filter(date__gte=six_months_ago).count()
    
    print(f"✓ Total Events Displayed: {total_events}")
    print(f"✓ Paid Events: {paid_events}")
    print(f"✓ Free Events: {free_events}")
    print(f"✓ Events (Last 6 Months): {recent_events}")
    print(f"✓ Total Registrations via Calendar: {total_registrations}")
    
    metrics['calendar'] = {
        'total_events_displayed': total_events,
        'paid_events': paid_events,
        'free_events': free_events,
        'recent_events': recent_events,
        'total_registrations': total_registrations,
        'avg_registrations_per_event': avg_registrations_per_event
    }
    
    # ========== SYSTEM INTEGRATION ==========
    print("\n" + "=" * 80)
    print("🔗 SYSTEM INTEGRATION METRICS")
    print("-" * 80)
    
    # Calculate total system transactions
    total_transactions = total_payments + EventPayment.objects.count()
    successful_transactions = verified_payments + EventPayment.objects.filter(status='completed').count()
    transaction_success_rate = round((successful_transactions / total_transactions * 100) if total_transactions > 0 else 0, 2)
    
    total_system_revenue = float(payment_revenue) + float(event_revenue)
    
    print(f"✓ Total Transactions: {total_transactions}")
    print(f"✓ Successful Transactions: {successful_transactions}")
    print(f"✓ Transaction Success Rate: {transaction_success_rate}%")
    print(f"✓ Total System Revenue: ₱{total_system_revenue:,.2f}")
    
    metrics['system_integration'] = {
        'total_transactions': total_transactions,
        'successful_transactions': successful_transactions,
        'transaction_success_rate': transaction_success_rate,
        'total_revenue': total_system_revenue
    }
    
    # ========== SAVE RESULTS ==========
    print("\n" + "=" * 80)
    print("💾 SAVING METRICS TO FILE")
    print("-" * 80)
    
    with open('research_metrics.json', 'w') as f:
        json.dump(metrics, f, indent=2, default=str)
    
    print("✓ Metrics saved to research_metrics.json")
    
    print("\n" + "=" * 80)
    print("✅ METRICS COLLECTION COMPLETE!")
    print("=" * 80)
    
    return metrics

if __name__ == '__main__':
    metrics = collect_metrics()
