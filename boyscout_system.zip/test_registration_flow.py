#!/usr/bin/env python
"""
Test Registration Flow with PayMongo
This script simulates a user registration to test the PayMongo integration
"""

import os
import sys
import django
import requests
from datetime import date
from pathlib import Path

# Load environment variables from .env file
from dotenv import load_dotenv
env_path = Path('/home/shun/Documents/boyscout_system') / '.env'
load_dotenv(dotenv_path=env_path)

# Setup Django environment
sys.path.append('/home/shun/Documents/boyscout_system')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'boyscout_system.settings')
django.setup()

from accounts.models import User, RegistrationPayment
from payments.services.paymongo_service import PayMongoService

def test_single_registration():
    """Test single registration flow"""
    print("\n" + "="*60)
    print("TESTING SINGLE REGISTRATION WITH PAYMONGO")
    print("="*60 + "\n")
    
    # Test data
    test_user_data = {
        'username': 'testuser_' + str(int(date.today().strftime('%Y%m%d'))),
        'first_name': 'Test',
        'last_name': 'User',
        'email': f'testuser_{int(date.today().strftime("%Y%m%d"))}@example.com',
        'password': 'TestPassword123',
        'phone_number': '+639171234567',
        'date_of_birth': '2000-01-01',
        'address': '123 Test Street, Manila',
    }
    
    print("📝 Test User Data:")
    print(f"   Name: {test_user_data['first_name']} {test_user_data['last_name']}")
    print(f"   Email: {test_user_data['email']}")
    print(f"   Username: {test_user_data['username']}")
    print(f"   Phone: {test_user_data['phone_number']}")
    print()
    
    # Check if user already exists
    if User.objects.filter(email=test_user_data['email']).exists():
        print("⚠️  User already exists. Deleting old test user...")
        User.objects.filter(email=test_user_data['email']).delete()
        print("✅ Old user deleted\n")
    
    # Step 1: Create user
    print("Step 1: Creating User...")
    user = User.objects.create_user(
        username=test_user_data['username'],
        email=test_user_data['email'],
        password=test_user_data['password'],
        first_name=test_user_data['first_name'],
        last_name=test_user_data['last_name'],
        phone_number=test_user_data['phone_number'],
        date_of_birth=test_user_data['date_of_birth'],
        address=test_user_data['address'],
        rank='scout',
        is_active=True,
        registration_status='pending'
    )
    print(f"✅ User created: ID={user.id}, Email={user.email}\n")
    
    # Step 2: Create RegistrationPayment
    print("Step 2: Creating RegistrationPayment...")
    reg_payment = RegistrationPayment.objects.create(
        user=user,
        amount=500.00,
        status='pending'
    )
    print(f"✅ RegistrationPayment created: ID={reg_payment.id}, Amount=₱{reg_payment.amount}\n")
    
    # Step 3: Create PayMongo Source
    print("Step 3: Creating PayMongo Source...")
    try:
        paymongo = PayMongoService()
        success, source_data = paymongo.create_source(
            amount=float(reg_payment.amount),
            description=f"Registration Payment - {user.get_full_name()}",
            redirect_success='http://127.0.0.1:8000/payments/payment-success/',
            redirect_failed='http://127.0.0.1:8000/payments/payment-failed/',
            metadata={
                'user_id': str(user.id),
                'payment_type': 'registration',
                'registration_payment_id': str(reg_payment.id)
            }
        )
        
        if source_data and 'data' in source_data and success:
            source = source_data['data']
            source_id = source['id']
            checkout_url = source['attributes'].get('redirect', {}).get('checkout_url')
            
            # Update registration payment with source ID
            reg_payment.paymongo_source_id = source_id
            reg_payment.save()
            
            print(f"✅ PayMongo Source created successfully!")
            print(f"   Source ID: {source_id}")
            print(f"   Status: {source['attributes']['status']}")
            print(f"   Amount: ₱{source['attributes']['amount'] / 100}")
            print(f"   Type: {source['attributes']['type']}")
            print()
            
            if checkout_url:
                print("="*60)
                print("🎉 SUCCESS! Registration flow ready for payment")
                print("="*60)
                print()
                print("📱 NEXT STEPS TO TEST PAYMENT:")
                print()
                print("1. Open this URL in your browser:")
                print(f"   {checkout_url}")
                print()
                print("2. Select payment method (GCash/PayMaya/GrabPay)")
                print()
                print("3. Use PayMongo TEST credentials:")
                print("   - For GCash: Use test QR code")
                print("   - For PayMaya: Use test card")
                print()
                print("4. Complete the payment")
                print()
                print("5. Check if webhook is received and user is activated")
                print()
                print("📊 Monitor the webhook at:")
                print("   Terminal: Watch server logs")
                print("   URL: http://127.0.0.1:8000/payments/paymongo/webhook/")
                print()
                print("📧 Check database after payment:")
                print(f"   User ID: {user.id}")
                print(f"   RegistrationPayment ID: {reg_payment.id}")
                print()
                print("="*60)
                
                # Save checkout URL to file for easy access
                with open('/tmp/paymongo_checkout_url.txt', 'w') as f:
                    f.write(checkout_url)
                print("\n✅ Checkout URL saved to: /tmp/paymongo_checkout_url.txt")
                
                return {
                    'success': True,
                    'user': user,
                    'registration_payment': reg_payment,
                    'source_id': source_id,
                    'checkout_url': checkout_url
                }
            else:
                print("❌ Error: No checkout URL returned")
                return {'success': False, 'error': 'No checkout URL'}
        else:
            print("❌ Error: Invalid response from PayMongo")
            print(f"Response: {source_data}")
            return {'success': False, 'error': 'Invalid PayMongo response'}
            
    except Exception as e:
        print(f"❌ Error creating PayMongo source: {str(e)}")
        import traceback
        traceback.print_exc()
        return {'success': False, 'error': str(e)}


def test_batch_registration():
    """Test batch registration flow"""
    print("\n" + "="*60)
    print("TESTING BATCH REGISTRATION WITH PAYMONGO")
    print("="*60 + "\n")
    
    from accounts.models import BatchRegistration, BatchStudentData
    from django.contrib.auth.hashers import make_password
    
    # Test data
    registrar_data = {
        'name': 'Teacher Maria',
        'email': f'teacher_{int(date.today().strftime("%Y%m%d"))}@school.com',
        'phone': '+639171234567',
    }
    
    students_data = [
        {
            'username': 'student1_test',
            'first_name': 'Juan',
            'last_name': 'Dela Cruz',
            'email': 'juan.test@school.com',
            'password': 'Password123',
            'phone_number': '+639181111111',
            'date_of_birth': '2010-01-01',
            'address': 'Manila'
        },
        {
            'username': 'student2_test',
            'first_name': 'Pedro',
            'last_name': 'Santos',
            'email': 'pedro.test@school.com',
            'password': 'Password123',
            'phone_number': '+639182222222',
            'date_of_birth': '2010-02-01',
            'address': 'Quezon City'
        },
        {
            'username': 'student3_test',
            'first_name': 'Maria',
            'last_name': 'Garcia',
            'email': 'maria.test@school.com',
            'password': 'Password123',
            'phone_number': '+639183333333',
            'date_of_birth': '2010-03-01',
            'address': 'Makati'
        }
    ]
    
    num_students = len(students_data)
    total_amount = num_students * 500.00
    
    print("📝 Batch Registration Data:")
    print(f"   Registrar: {registrar_data['name']}")
    print(f"   Email: {registrar_data['email']}")
    print(f"   Number of students: {num_students}")
    print(f"   Total amount: ₱{total_amount}")
    print()
    
    # Step 1: Create BatchRegistration
    print("Step 1: Creating BatchRegistration...")
    batch = BatchRegistration.objects.create(
        registrar_name=registrar_data['name'],
        registrar_email=registrar_data['email'],
        registrar_phone=registrar_data['phone'],
        number_of_students=num_students,
        amount_per_student=500.00,
        total_amount=total_amount,
        status='pending'
    )
    print(f"✅ BatchRegistration created: ID={batch.id}, Batch ID={batch.batch_id}\n")
    
    # Step 2: Create BatchStudentData
    print("Step 2: Creating BatchStudentData for each student...")
    for idx, student in enumerate(students_data, 1):
        BatchStudentData.objects.create(
            batch_registration=batch,
            username=student['username'],
            first_name=student['first_name'],
            last_name=student['last_name'],
            email=student['email'],
            phone_number=student['phone_number'],
            date_of_birth=student['date_of_birth'],
            address=student['address'],
            password_hash=make_password(student['password'])
        )
        print(f"   ✅ Student {idx}: {student['first_name']} {student['last_name']}")
    print()
    
    # Step 3: Create PayMongo Source
    print("Step 3: Creating PayMongo Source for batch...")
    try:
        paymongo = PayMongoService()
        success, source_data = paymongo.create_source(
            amount=float(total_amount),
            description=f"Batch Registration - {registrar_data['name']} ({num_students} students)",
            redirect_success='http://127.0.0.1:8000/payments/payment-success/',
            redirect_failed='http://127.0.0.1:8000/payments/payment-failed/',
            metadata={
                'payment_type': 'batch_registration',
                'batch_registration_id': str(batch.id),
                'number_of_students': num_students,
                'registrar_email': registrar_data['email']
            }
        )
        
        if source_data and 'data' in source_data and success:
            source = source_data['data']
            source_id = source['id']
            checkout_url = source['attributes'].get('redirect', {}).get('checkout_url')
            
            # Update batch with source ID
            batch.paymongo_source_id = source_id
            batch.save()
            
            print(f"✅ PayMongo Source created successfully!")
            print(f"   Source ID: {source_id}")
            print(f"   Amount: ₱{source['attributes']['amount'] / 100}")
            print()
            
            if checkout_url:
                print("="*60)
                print("🎉 SUCCESS! Batch registration ready for payment")
                print("="*60)
                print()
                print("📱 NEXT STEPS:")
                print()
                print("1. Open checkout URL:")
                print(f"   {checkout_url}")
                print()
                print("2. Pay ₱{:.2f} via GCash/PayMaya/GrabPay".format(total_amount))
                print()
                print(f"3. After payment, {num_students} student accounts will be created automatically!")
                print()
                print("📊 Students to be created:")
                for student in students_data:
                    print(f"   - {student['first_name']} {student['last_name']} ({student['email']})")
                print()
                print("="*60)
                
                return {
                    'success': True,
                    'batch': batch,
                    'checkout_url': checkout_url
                }
                
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return {'success': False, 'error': str(e)}


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Test PayMongo Registration Flow')
    parser.add_argument('--type', choices=['single', 'batch'], default='single',
                      help='Type of registration to test (single or batch)')
    
    args = parser.parse_args()
    
    if args.type == 'single':
        result = test_single_registration()
    else:
        result = test_batch_registration()
    
    if result and result.get('success'):
        print("\n✅ Test completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Test failed!")
        sys.exit(1)
