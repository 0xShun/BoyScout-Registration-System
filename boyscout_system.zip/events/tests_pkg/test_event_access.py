from django.test import TestCase, Client
from django.utils import timezone
from decimal import Decimal

from accounts.models import User
from events.models import Event


class TestEventAccess(TestCase):
    def setUp(self):
        # Create an active scout user
        self.email = 'testscout@example.com'
        self.password = 'test-pass-123'
        self.user = User.objects.create(
            email=self.email,
            username='testscout',
            first_name='Test',
            last_name='Scout',
            rank='scout',
            is_active=True,
            registration_status='active',
            registration_total_paid=Decimal('500.00'),
            registration_amount_required=Decimal('500.00'),
        )
        self.user.set_password(self.password)
        self.user.save()

        # Ensure an event exists
        self.event = Event.objects.create(
            title='Smoke Test Event',
            description='Event for smoke test',
            date=timezone.now().date(),
            time=timezone.now().time(),
            location='Test Venue',
            created_by=self.user,
        )

    def test_active_user_can_access_events_list_and_calendar(self):
        client = Client()
        # login with email (USERNAME_FIELD=email)
        logged = client.login(email=self.email, password=self.password)
        self.assertTrue(logged, 'Failed to login test user')

        resp = client.get('/events/')
        self.assertEqual(resp.status_code, 200)

        resp2 = client.get('/events/calendar-data/')
        self.assertEqual(resp2.status_code, 200)
